-- Copyright (C) 2023 SuperAdmin
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see https://www.gnu.org/licenses/.


CREATE TABLE llx_dolibinance_transaction(
	-- BEGIN MODULEBUILDER FIELDS
	rowid integer AUTO_INCREMENT PRIMARY KEY NOT NULL, 
        fk_facture integer,
	transaction_hash varchar(128), 
	from_address varchar(128) NOT NULL, 
	asset varchar(8) NOT NULL, 
	network varchar(64) NOT NULL, 
	to_address varchar(128) NOT NULL, 
	amount_to_pay real NOT NULL, 
	creation_date datetime NOT NULL, 
	state integer NOT NULL
	-- END MODULEBUILDER FIELDS
) ENGINE=innodb;
