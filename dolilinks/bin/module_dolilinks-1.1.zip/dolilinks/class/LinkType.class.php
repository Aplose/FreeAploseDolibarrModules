<?php
class LinkType
{
    private DoliDB  $_db;

    public int      $id;
    public int      $entity;
    public string   $date_creation;
    public string   $tms;
    public int      $fk_user_creat;
    public string   $label;

    public function __construct(DoliDB $db)
    {
        $this->_db = $db;
    }


    public function fetch(int $id, $langs = null): void
    {
        if (is_null($id) || $id === 0 || $id < 0) {
            throw new Exception($langs ? $langs->trans("INCORRECT_ID_TO_FETCH_LINKTYPE", $id) : "Incorrect id (" . $id . ") to fetch LinkType");
        }
        $sql = "SELECT * FROM " . MAIN_DB_PREFIX . "c_dolilinks_link_type WHERE rowid=" . $id;
        $resql = $this->_db->query($sql);
        if ($resql === false) {
            throw new Exception(($langs ? $langs->trans("SQL_ERROR") . ": " : "SQL error: ") . $this->_db->lasterror());
        }
        $arr = $this->_db->fetch_array($resql);
        if (is_null($arr) || $arr === false) {
            throw new Exception($langs ? $langs->trans("FAIL_TO_FETCH_LINKTYPE") . ": " . $this->_db->lasterror() : "Fail to fetch LinkType as array: " . $this->_db->lasterror());
        }
        $this->id               = $arr['rowid'];
        // $this->entity           = $arr['entity'];
        // $this->date_creation    = $arr['date_creation'];
        // $this->tms              = $arr['tms'];
        // $this->fk_user_creat    = $arr['fk_user_creat'];
        $this->label            = $arr['label'];
    }



    public function create(User $user, string $label, $langs = null): void
    {
        global $conf;
        $sql = "INSERT INTO " . MAIN_DB_PREFIX . "dolilinks_c_link_type (";
        $sql .= "label,";
        $sql .= "entity,";
        $sql .= "date_creation,";
        $sql .= "fk_user_creat,";
        $sql .= "fk_user_modif";
        $sql .= ") VALUES (";
        $sql .= "'".$this->_db->escape($label) . "',";
        $sql .= $conf->entity . ",";
        $sql .= "'".$this->_db->idate(dol_now()) . "',";
        $sql .= $user->id.',';
        $sql .= $user->id;
        $sql .= ")";

        if ($this->_db->query($sql) === false) {
            throw new Exception($langs ? $langs->trans("FAIL_TO_CREATE_LINKTYPE") . ": " . $this->_db->lasterror() : "Fail to create new LinkType. Error: " . $this->_db->lasterror());
        }
    }



    // public function delete(int $id): void 
    // {
    //     $sql = "DELETE FROM ".MAIN_DB_PREFIX."c_dolilinks_link_type WHERE rowid=".$id;
    //     if ($this->_db->query($sql) === false) {
    //         throw new Exception("Fail to delete LinkType with id ".$id.". Error: " . $this->_db->lasterror());
    //     }
    // }


    /** @return LinkType[] */
    public function getAll($langs = null): array
    {
        global $conf;
        $sql = "SELECT rowid as id FROM ".MAIN_DB_PREFIX."c_dolilinks_link_type";
        $resql = $this->_db->query($sql);
        if ($resql === false) {
            throw new Exception(($langs ? $langs->trans("SQL_ERROR") . ": " : "SQL error: ") . $this->_db->lasterror());
        }
        $linkTypes = [];
        while($arr = $this->_db->fetch_array($resql)){
            $linkType = new LinkType($this->_db, $conf);
            $linkType->fetch($arr['id'], $langs);
            $linkTypes[$arr['id']] = $linkType; 
        }
        return $linkTypes;
    }




}
