CREATE TABLE IF NOT EXISTS llx_c_dolilinks_link_type (
    rowid int AUTO_INCREMENT PRIMARY KEY,
    code varchar(32) NOT NULL,
    label varchar(255) NOT NULL
) ENGINE=innodb;
