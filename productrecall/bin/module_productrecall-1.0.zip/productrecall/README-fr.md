# RAPPEL PRODUIT POUR DOLIBARR

Pensez à la sécurité de vos clients en surveillant les alertes conso !  
  
![Screenshot ProductRecall](img/productrecall-screenshot-001.png?raw=true "ProductRecall")  

## Fonctionnalités
Ce module permet de suivre les rappels de produits de consommation officiels et d'être alerté par email.  
Il est possible de paramétrer un filtre sur les catégories de produits et/ou les sous catégories.  
Un widget est fourni en page d'accueil avec les derniers rappels.  
Un travail planifié est fourni et doit être activé. Lors du premier lancement, tous les rappels présents sur le site RappelConso officel sont rappatriés.  

## A venir
Rien n'est prévu pour le moment mais n'hésitez pas à remonter vos remarques à ce sujet à [Olivier Andrade Sanchez](mailto:oandrade@aplose.fr?subject=[ProdutRecallRequest]-).  

## Configuration

### Email
Afin de recevoir les emails d'alerte conso, il est nécessaire d'avoir paramétré l'envoi d'eamil dans Dolibarr au préalable puis d'ajouter une adresse mail (ou plusieurs séparées par des virgules) dans le champ prévu à cet effet.  
![Screenshot email](img/productrecall-screenshot-002.png?raw=true "Email")  

### Filtre Catégories et Sous-catégories
Vous pouvez séléectionner autant de filtres de catégories et/ou sous-catégories que souhaité.  
![Screenshot filtres](img/productrecall-screenshot-003.png?raw=true "Filtres")  
Les filtres s'ajoutent donc inutiles de sélectionner la catégorie "Alimentation" et la sous-catégorie "Viandes" car celle-ci est déjà contenue dans "Alimentation". Par contre vous pouvez sélectionner la sous-catégorie "Viandes" uniquement et vous n'aurez que les alertes de ces produits.  
Si vous souhaitez tous les rappels produits, ne mettez aucun filtre.  
![Screenshot filtres 2](img/productrecall-screenshot-004.png?raw=true "Filtres 2")  

## Utilisation

###Job de vérification des rappels produits (travaux automatisés)
Un job (programme lancé automatiquement ou manuellement) est fourni afin de charger manuellement la première fois votre base de données de rappels produits (pensez à paramétrer vos filtres selon vos préférences sinon vous chargerez tous les rappels produits).  
Dans "Outils d'administration -> Travaux planifiés", activez le job "Vérifiation des rappels produits" puis lancez le !  
![Screenshot job](img/productrecall-screenshot-005.png?raw=true "Job")  
La première fois ils est néessaire d'attendre quelques minutes...  
![Screenshot job 2](img/productrecall-screenshot-006.png?raw=true "Job 2")  

Ensuite, toutes les dix minutes, si vous avez correctement configuré votre Dolibarr afin qu'il exécute régulièrement les tâches planifiées, le job sera exécuté automatiquement et vous recevrez un email si vous avez des rappels vous concernant (et que l'email est bien paramétré...).  
  
Lorsque des rappels produits correspondent à vos filtres et que vous avez paramétré au moins une adresse et l'envoi d'email, vous recevrez un mail ainsi constitué :  
![Screenshot mail sent](img/productrecall-screenshot-007.png?raw=true "Mail sent")  
Vous remarquerez que de nombreuses informations sont à votre disposition comme le téléchargement de l'affichette PDF à afficher près de la caisse.  

###Écran des Rappels Produits
Vous pouvez retrouver tous les rappels produits actuels et passés en cliquant sur le lien du menu haut.  
Vous pouvez filtrer cette liste en utilisant vos techniques habituelle dans les champs de filtre (ici avec %carotte% pour trouver les produits contenant le mot carotte).  
![Screenshot screen recall](img/productrecall-screenshot-008.png?raw=true "Screen recall")  
  

##Restons en contact !
N'hésitez pas à me faire part de vos idées et remarques à [oandrade@aplose.fr](mailto:oandrade@aplose.fr).  

## Licenses

### Code principal

GPLv3.

### Documentation

Tous les textes et readmes sont sous licence GFDL.
